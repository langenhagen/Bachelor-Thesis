1. Je nach System 32 oder 64 Bit Version beziehen.
2. Entpacken.
3. HomeViewer.bat starten.
4. Ein Dialog fragt, welchen Dialogtypen man zur Auswahl des Context Modells nutzen will. Entweder eine avantgarde MT4j-Version oder einen klassischen Java Swing Dialog.
5. ContextModell (.xmi) ausw�hlen und laden.

Alternativ kann man auch HomeViewer_Classic.bat starten. Hierbei wird eine alte version mit manuell erzeugtem Wohnungsmodell gestartet. Es empfiehlt sich, das ContextModel_Offline_Classic.xmi zu benutzen, da dies an dieses 3D-Modell angepasst ist.

Als Dokumentation des Home Viewer steht meine Bachelorarbeit hier zur Verf�gung:
http://hrny.de/Andreas_Langenhagen-Implementierung_eines_3D_User_Interfaces.pdf

Fragen bitte an: andreas.langenhagen@dai-labor.de
Version 20121002